# Changelog

> **Tags:**
> - [New Feature]
> - [Bug Fix]
> - [Spec Compliancy]
> - [Breaking Change]
> - [Documentation]
> - [Internal]
> - [Polish]

## 4.4.7

 * **Bug Fix**
  * Rebillia Style changed.

## 4.4.6

 * **Bug Fix**
  * Main page Japonesque Brand image fixed.

## 4.4.5

 * **New Feature**
  * Main page Newsletter part edited.

## 4.4.4

 * **New Feature**
  * Home Page's Becca link changed to Japonesque.
  * Change the location of Add to Cart snippet

## 4.4.3

 * **New Feature**
  * Add discountinued alert-error for products having discountinued custom-field.
  * Remove zero price products from best sellers.
